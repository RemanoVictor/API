import { combineReducers } from "redux";

import graphData from "./graphData";

const rootReducer = combineReducers({
  graphData,
});

export default rootReducer;
